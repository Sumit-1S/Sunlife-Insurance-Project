package com.example.springmicroserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMicroServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
