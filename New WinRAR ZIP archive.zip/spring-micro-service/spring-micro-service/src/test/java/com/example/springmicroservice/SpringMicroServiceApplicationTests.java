package com.example.springmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
