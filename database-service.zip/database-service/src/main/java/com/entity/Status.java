package com.entity;

public enum Status {
	ACTIVE, INACTIVE

}
