package com.entity;

public enum PolicyType {
	HEALTH, ACCIDENTAL, LIFE

}
